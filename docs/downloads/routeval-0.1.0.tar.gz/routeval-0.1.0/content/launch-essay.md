# Our AI answered correctly on 40 cases that took a different route than the policy expected

*What separating answer quality from routing quality taught me, and why I
extracted Routeval from Quorum.*

Quorum routes visual recycling decisions through a detector, an adjudicator,
and a human queue. Its first headline score gave me a number. Decomposing that
number gave me a more useful question: which part of the system should I change?

## Answer quality and routing quality are different measurements

On Quorum's verified run 6, 124 of 184 attempted cases had the correct verdict:
67.4% accuracy. Forty cases had a correct verdict but disagreed with the
expected route label. That is **21.7% of all attempted cases**, or **32.3% of
correct verdicts**. Those are different denominators.

The 40 cases also contain two different problems: **34 missed escalations**
with correct answers and **six unnecessary escalations** with correct answers.
The former raises a policy and safety question; the latter raises a spend
question. Neither establishes that the answer was accidental, nor that the
labelled route would have produced a better answer.

An earlier draft called the whole cell “lucky hits” and described 22% as a
share of correct answers. Both claims overstated what the evidence showed.
Run 2 also used machine-drafted labels; run 6 is the later verified reference.
The golden set has not been established as an independent production holdout,
so these are diagnostic findings on that set, not generalization guarantees.

## An escalation needs to earn its place

A correct final verdict can conceal an unnecessary expensive call. A wrong
verdict can conceal a well-routed case whose downstream model failed. Those
lead to different changes: tune the policy, improve the escalation, or revisit
the route labels. A report needs to keep those possibilities visible.

Similarly, a free local model can be an escalation. The cheapest observed
route is not automatically the fast path. Missing provider cost is not zero
spend. A comparison is only useful when the dataset, scoring policy, route
roles, and cost basis are held constant.

## Routeval makes that report repeatable

Routeval takes a Python callable returning an answer, its route, and its
whole-decision cost. It replays labelled examples and writes a versioned JSON
artifact with:

- accuracy over all attempted cases, with failures visible;
- accuracy, cost coverage, and latency by actual route;
- complete spend per correct answer, or an explicit unavailable value;
- automatic completion rate for declared route roles;
- expected-route agreement and escalation precision/recall when route labels exist;
- a baseline comparison that fails when measurement is incomplete or incomparable.

Bring your own scoring function or judge. Existing evaluation tools also
support custom scoring and costs; Routeval's contribution is a small,
consistent routing-and-economics report with explicit denominators and a
reusable artifact. It can fit alongside the tools a team already uses.

The offline support-bot demo contains 20 examples and one deliberate failure.
It tests the reporting contract without requiring model keys. The functional
0.1.0 candidate is locally implemented and verified; the PyPI 0.0.1 reservation
is not that implementation. The [README](../README.md) gives current install
instructions.

## The next evidence should come from other users

I want to test this with three independent pipelines: a local/hosted cascade,
a support handoff, and a rules/LLM extraction flow. The first trial is simple:
can the owner wrap their pipeline, label five examples, and get a report that
changes a concrete decision? Their friction should determine the next feature.

The [Quorum audit](https://nicopurnomo.me/12-Quorum-Audit) contains the case study.
Route agreement remains agreement with a labelled policy; it is not proof of
route optimality or of a lucky answer.
