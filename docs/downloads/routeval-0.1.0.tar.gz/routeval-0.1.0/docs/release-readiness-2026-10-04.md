# Routeval 0.1.0 — release readiness

## Implemented

- Explicit automatic and escalation roles; free escalation stays an escalation.
- Complete-cost reporting and gates; unknown spend is never counted as free.
- Scorer and decision validation failures retain booked cost and attempted rows.
- Versioned scorer, route policy, pricing contents, golden set, and cost basis
  are checked before baseline execution; edited aggregates cannot gate CI.
- Zero-to-paid cost and disappearing escalations fail comparison when regressed.
- Unique atomic schema-1 artifacts include their path and complete baseline block.
- Sync and sequential async callables; strict boolean scorers and strict JSON values.
- Config-based offline quickstart, quality limits, and aggregate sharing command.
- Version-consistent source/wheel packaging; redundant template inclusion removed.
- Documentation and origin story corrected; public 0.0.1 remains a placeholder.

## Verification

Locally verified on macOS arm64 with Python 3.14.6:

| Check | Result |
|---|---|
| Source tests | 88 passed; no provider or model calls |
| Ruff check / formatting | Passed |
| Whitespace diff check | Passed |
| Source archive build | Passed |
| Wheel built **from that source archive** | Passed |
| Twine metadata and README checks | Both distributions passed |
| Fresh temporary environment, no source path or network | Installed wheel passed |
| Bare `routeval init` then `routeval run` | Expected 20 attempts, 16 correct, one allowed demo failure |
| Persisted comparison and aggregate summary | Passed |
| README five-example wrapper | Five correct; $0.025 total; $0.005 per correct |
| Lower-cost revision / wrong-answer revision | Exit 0 / exit 1 respectively |

The core adds no required dependencies. CI is configured for source tests
on Python 3.10–3.14 and installed package checks on Linux, Windows, and macOS.
Those remote jobs have not run; the local result does not establish their result.

## Contract change

Package version: **0.1.0**. Artifact schema: **1**. Schema-0 runs need
regeneration with explicit roles and costs; they are not valid baselines.
Numeric custom scorer results need an explicit boolean threshold. Paid
provider prices must be reported or supplied by the user. Full artifacts are
private by default; the summary removes item contents but retains route/stage names.

The report measures agreement with labelled routing policy. It does not prove
optimal routes, accidental answers, production generalization, or provider-bill
reconciliation. Multi-call costs remain the wrapper owner's responsibility.

## Publication remaining

GitHub authentication in this environment is invalid; the local repository has
no configured remote. No PyPI publishing credentials are configured. Choose
or provide the public repository, configure Source/Issues metadata, authenticate
publication, push the branch and let CI run, then upload the verified 0.1.0
artifacts. The package has **not** been publicly released in this session.

The next adoption work is three independent five-example pipeline trials.
The original adoption review is preserved separately. No Quorum models were
called and no Quorum database or settled architecture decisions were changed.
