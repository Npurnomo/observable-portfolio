# Adoption plan — 0.1.0 candidate

The first batch makes measurement and installation dependable. Broad adoption
still needs evidence from independent pipelines.

## Current state

- Functional harness, schema 1, CLI, offline demo, five-case wrapper, and
  installed distribution verification are implemented.
- CI definitions cover Python 3.10–3.14 source tests and installed packages
  on Linux, Windows, and macOS. Remote CI has not run here.
- Public PyPI 0.0.1 is the name reservation. Publish 0.1.0 only after source
  and issue URLs are configured and the publication accounts authenticate.
- Launch narrative uses verified Quorum run 6 and distinguishes answer/route
  mismatches from proof of luck or optimal routing.

## First three adoption trials

| Trial | Owner provides | Evidence to record |
|---|---|---|
| Local/hosted model cascade | Callable, five labelled cases, whole-decision spend | Does a free escalation stay correctly classified? |
| Support with human handoff | Policy labels and an explicit human/API cost basis | Does escalation recall reveal missed handoffs? |
| Rules followed by LLM extraction | Expected answers, role declarations, one changed policy | Does a baseline catch a quality or spend regression? |

Record time to first report, adapter lines, confusing labels, missing cost,
and the decision the report changed. Success is an owner reproducing the run
and explaining a useful finding, not a download count. Seek real volunteers;
do not invent candidates or publish unsolicited messages.

## Feature gate

Keep the callable as the first entry point. A results-file import, additional
recipes, or concurrency should follow recurring friction in these trials.
No full trace ingestion, new judge, dashboard, response cache, or paid model
experiments are required for this batch.

After the trials, prepare a public package page and article on nicopurnomo.me
using reproducible demo artifacts and verified install instructions. Avoid
claiming that existing evaluation tools cannot handle custom routing scores.

## Wider launch and traction

The original target remains twelve external users evidenced by issues/PRs, or
two users not personally onboarded, after four weeks of distribution effort.
Start that clock after a functional public release. If it fails, consider
contributing the report/scorers to existing evaluation tools.

## Trial log

| Date | Pipeline / owner | Time to first report | Friction | Decision changed |
|---|---|---|---|---|
| Pending | | | | |
