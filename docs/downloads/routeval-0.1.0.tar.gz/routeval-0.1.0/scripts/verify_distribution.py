"""Verify a built wheel from a clean install; no network or model calls."""

from __future__ import annotations

import json
import math
import os
import subprocess
import sys
import tempfile
import venv
from pathlib import Path


def check_distribution(wheel: Path) -> None:
    wheel = wheel.resolve(strict=True)
    env = {k: v for k, v in os.environ.items() if k not in {"PYTHONPATH", "PYTHONHOME"}}
    env["PYTHONNOUSERSITE"] = "1"
    with tempfile.TemporaryDirectory(prefix="routeval-installed-") as directory:
        root = Path(directory)
        venv.EnvBuilder(with_pip=True).create(root / "env")
        binaries = root / "env" / ("Scripts" if os.name == "nt" else "bin")
        python = binaries / ("python.exe" if os.name == "nt" else "python")
        command = binaries / ("routeval.exe" if os.name == "nt" else "routeval")

        def call(args: list[str], code: int = 0) -> subprocess.CompletedProcess[str]:
            result = subprocess.run(
                args, cwd=root, env=env, capture_output=True, text=True, check=False
            )
            if result.returncode != code:
                raise AssertionError(
                    f"{args}: exit {result.returncode}\n{result.stdout}{result.stderr}"
                )
            return result

        call([str(python), "-m", "pip", "install", "--no-index", "--no-deps", str(wheel)])
        version = call(
            [
                str(python),
                "-c",
                (
                    "import importlib.metadata, routeval; "
                    "assert routeval.__version__ == importlib.metadata.version('routeval'); "
                    "assert not importlib.metadata.requires('routeval') or all("
                    "'extra ==' in r for r in importlib.metadata.requires('routeval')); "
                    "print(routeval.__version__)"
                ),
            ]
        ).stdout.strip()
        assert call([str(command), "--version"]).stdout.strip() == f"routeval {version}"
        call([str(command), "init"])
        call([str(command), "run"])
        paths = set((root / "runs").glob("*.json"))
        assert len(paths) == 1
        first = paths.pop()
        artifact = json.loads(first.read_text())
        a = artifact["aggregates"]
        assert artifact["schema_version"] == "1" and a["attempted"] == 20
        assert a["errors"] == 1 and a["measurement_errors"] == 0
        assert a["accuracy_attempted"] == 0.8
        assert math.isclose(a["economics"]["total_cost_usd"], 0.0613)
        assert math.isclose(a["economics"]["cost_per_correct_usd"], 0.0613 / 16)
        assert math.isclose(a["routing"]["escalation_recall"], 6 / 7)
        call([str(command), "run", "--baseline", str(first)])
        current = (set((root / "runs").glob("*.json")) - {first}).pop()
        assert json.loads(current.read_text())["baseline"]["status"] == "pass"
        call([str(command), "compare", str(current), str(first)])
        call([str(command), "summary", str(current), "--output", "summary.json"])
        summary = json.loads((root / "summary.json").read_text())
        assert summary["summary_only"] and "items" not in summary

        answers = {
            "hours": "9–5",
            "address": "London",
            "refund": "review",
            "billing": "review",
            "hello": "hello",
        }
        rows = [
            {
                "id": str(n),
                "input": key,
                "expected": value,
                "expected_route": "review" if key in {"refund", "billing"} else "fast",
            }
            for n, (key, value) in enumerate(answers.items())
        ]
        (root / "golden.jsonl").write_text(
            "\n".join(json.dumps(row) for row in rows), encoding="utf-8"
        )
        pipeline = (
            "from routeval import Decision\nANSWERS = "
            + repr(answers)
            + "\n"
            + (
                "def evaluate(text):\n"
                "    route = 'review' if text in {'refund', 'billing'} else 'fast'\n"
                "    return Decision(ANSWERS[text], route, 0.011 if route == 'review' else 0.001)\n"
            )
        )
        (root / "pipeline.py").write_text(pipeline, encoding="utf-8")
        args = [
            str(command),
            "run",
            "--pipeline",
            "pipeline.py:evaluate",
            "--golden",
            "golden.jsonl",
            "--auto-route",
            "fast",
            "--escalation-route",
            "review",
            "--cost-basis",
            "api-only",
            "--runs-dir",
            "custom-runs",
        ]
        call([*args, "--min-accuracy", "0.9", "--min-escalation-recall", "1"])
        baseline = next((root / "custom-runs").glob("*.json"))
        result = json.loads(baseline.read_text())
        assert result["aggregates"]["accuracy_attempted"] == 1
        assert math.isclose(result["aggregates"]["economics"]["cost_per_correct_usd"], 0.005)
        (root / "pipeline.py").write_text(
            pipeline.replace("0.011", "0.0055").replace("else 0.001", "else 0.0005"),
            encoding="utf-8",
        )
        call([*args, "--baseline", str(baseline)])
        (root / "pipeline.py").write_text(
            pipeline.replace(
                "Decision(ANSWERS[text]", "Decision('wrong' if text == 'hours' else ANSWERS[text]"
            ),
            encoding="utf-8",
        )
        call([*args, "--baseline", str(baseline)], code=1)
        print(
            f"PASS: installed {version}; offline init/run, persisted comparison, summary, "
            "five-case wrapper, improvement and regression exits"
        )


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python scripts/verify_distribution.py <wheel>")
    check_distribution(Path(sys.argv[1]))
