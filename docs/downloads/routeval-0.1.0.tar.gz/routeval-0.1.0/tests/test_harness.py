"""Harness behavior: dead-letters, privacy defaults, manifest, cost resolution."""

from routeval import Decision, Harness

GOLDEN = [
    {"input": "hello", "expected": "world"},
    {"input": "boom", "expected": "anything"},
]


def flaky(user_input: str) -> Decision:
    if user_input == "boom":
        raise ValueError("kaboom")
    return Decision(answer="world", route="cheap", cost_usd=0.001)


def test_exceptions_are_dead_lettered_not_swallowed():
    run = Harness(flaky, runs_dir=None).run(GOLDEN)
    a = run["aggregates"]
    assert a["attempted"] == 2 and a["errors"] == 1
    assert a["accuracy_attempted"] == 0.5  # error counts against
    errored = [i for i in run["items"] if i["error"]]
    assert len(errored) == 1 and "kaboom" in errored[0]["error"]


def test_wrong_return_type_is_dead_lettered():
    run = Harness(lambda x: "not a Decision", runs_dir=None).run([{"input": "a", "expected": "a"}])
    item = run["items"][0]
    assert item["error"] and "expected Decision" in item["error"]
    assert run["aggregates"]["errors"] == 1


def test_inputs_are_hashed_not_echoed_by_default():
    run = Harness(flaky, runs_dir=None).run([{"input": "secret text", "expected": "x"}])
    item = run["items"][0]
    assert "input_echo" not in item
    assert len(item["input_hash"]) == 64
    assert "secret text" not in str(run)


def test_echo_inputs_opt_in():
    run = Harness(flaky, echo_inputs=True, runs_dir=None).run(
        [{"input": "hello", "expected": "world"}]
    )
    assert run["items"][0]["input_echo"] == "hello"


def test_manifest_pins_config_and_golden():
    run = Harness(flaky, runs_dir=None).run(GOLDEN, note="n1")
    m = run["manifest"]
    assert run["schema_version"] == "1"
    assert m["golden_set"]["n"] == 2 and len(m["golden_set"]["sha256"]) == 64
    assert len(m["config_hash"]) == 64
    assert m["note"] == "n1"


def test_cost_resolution_from_model_and_tokens():
    def priced(user_input: str) -> Decision:
        return Decision(
            answer="world", route="cheap", model="stub-small", tokens_in=1_000_000, tokens_out=0
        )

    run = Harness(priced, runs_dir=None).run([{"input": "hello", "expected": "world"}])
    assert run["items"][0]["cost_usd"] == 0.1  # bundled pricing: 0.35/1M in


def test_unknown_model_cost_is_none_and_counted():
    def mystery(user_input: str) -> Decision:
        return Decision(answer="world", route="cheap", model="unknown-model-xyz")

    run = Harness(mystery, runs_dir=None).run([{"input": "hello", "expected": "world"}])
    assert run["items"][0]["cost_usd"] is None
    assert run["aggregates"]["economics"]["unknown_cost_n"] == 1


def test_runs_dir_none_writes_nothing(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    Harness(flaky, runs_dir=None).run(GOLDEN)
    assert not (tmp_path / "runs").exists()


def test_artifact_written_when_runs_dir_set(tmp_path):
    run = Harness(flaky, runs_dir=tmp_path / "runs").run(GOLDEN)
    assert (tmp_path / "runs").exists()
    assert "artifact_path" in run["manifest"]
