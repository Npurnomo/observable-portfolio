"""Metrics verified against hand-computed values (no harness involved)."""

import pytest

from routeval import metrics


def rec(correct, route, cost, expected_route=None, latency=100.0, stages=None):
    return {
        "correct": correct,
        "route": route,
        "cost_usd": cost,
        "expected_route": expected_route,
        "latency_ms": latency,
        "stages": stages,
    }


def test_accuracy_over_attempted_counts_errors_against_you():
    items = [rec(True, "cheap", 0.1), rec(False, None, None)]  # second is an error
    assert metrics.accuracy_attempted(items) == 0.5


def test_per_route_groups_and_errors_bucket():
    items = [rec(True, "cheap", 0.1), rec(False, "cheap", 0.3), rec(False, None, None)]
    table = metrics.per_route(items)
    assert table["cheap"]["n"] == 2
    assert table["cheap"]["accuracy"] == 0.5
    assert table["cheap"]["cost_usd"] == pytest.approx(0.4)
    assert table["[unknown route]"]["n"] == 1


def test_economics_cost_per_correct_and_unknown_costs():
    items = [
        rec(True, "a", 0.30),
        rec(True, "a", 0.10),
        rec(False, "a", 0.60),
        rec(True, "b", None),
    ]
    e = metrics.economics(items)
    assert e["total_cost_usd"] is None
    assert e["known_cost_usd"] == pytest.approx(1.0)
    assert e["cost_per_correct_usd"] is None
    assert e["unknown_cost_n"] == 1


def test_economics_no_correct_yields_none():
    assert metrics.economics([rec(False, "a", 1.0)])["cost_per_correct_usd"] is None


def test_deflection_rate_uses_declared_auto_role():
    items = [rec(True, "cheap", 0.001)] * 3 + [rec(True, "big", 0.5)]
    e = metrics.economics(items, auto_routes=["cheap"])
    assert e["auto_routes"] == ["cheap"]
    assert e["deflection_rate"] == pytest.approx(0.75)


def test_routing_grid_lucky_and_escalation_pr():
    items = [
        rec(True, "cheap", 0.001, "cheap"),  # rr/vr
        rec(False, "cheap", 0.001, "cheap"),  # rr/vw
        rec(True, "cheap", 0.001, "escalate"),  # correct answer, missed escalation
        rec(False, "cheap", 0.001, "escalate"),  # rw/vw
        rec(True, "escalate", 0.5, "escalate"),  # rr/vr
        rec(True, "escalate", 0.5, "cheap"),  # correct answer, unnecessary escalation
    ]
    r = metrics.routing(items, escalation_routes=["escalate"])
    assert r["n_labelled"] == 6
    assert r["grid"]["route_wrong_verdict_right"] == 2
    assert r["lucky_hit_rate"] == pytest.approx(2 / 6)
    assert r["escalation_routes"] == ["escalate"]
    # sent to escalate: 2, of which warranted: 1
    assert r["escalation_precision"] == pytest.approx(0.5)
    # should escalate: 3, got there: 1
    assert r["escalation_recall"] == pytest.approx(1 / 3)


def test_routing_absent_without_labels():
    assert metrics.routing([rec(True, "cheap", 0.1)]) is None


def test_escalation_metrics_require_declared_roles():
    r = metrics.routing([rec(True, "only", 0.1, "only")])
    assert r["escalation_routes"] == []


def test_stage_accuracy_only_over_user_scored_stages():
    items = [
        rec(True, "a", 0.1, stages={"retrieve": {"correct": True}, "notes": {"x": 1}}),
        rec(False, "a", 0.1, stages={"retrieve": {"correct": False}}),
        rec(True, "a", 0.1, stages=None),
    ]
    s = metrics.stage_accuracy(items)
    assert s == {"retrieve": {"n": 2, "accuracy": 0.5}}
    assert metrics.stage_accuracy([rec(True, "a", 0.1)]) is None


def test_p95_nearest_rank():
    assert metrics._p95([]) == 0.0
    assert metrics._p95([7.0]) == 7.0
    assert metrics._p95([float(i) for i in range(1, 101)]) == 95.0
