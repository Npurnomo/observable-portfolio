from routeval import scorers


def test_exact():
    assert scorers.exact("4", "4")
    assert not scorers.exact("4", 4)


def test_normalized():
    assert scorers.normalized("  Yes ", "yes")
    assert scorers.normalized("A  B", "a b")
    assert not scorers.normalized("yes", "no")


def test_contains():
    assert scorers.contains("8pm", "Our cutoff is 8PM sharp.")
    assert not scorers.contains("9pm", "Our cutoff is 8PM sharp.")
