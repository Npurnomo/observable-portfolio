"""End-to-end on the zero-key toy: the numbers the hello world (and the
launch essay's report claims) must reproduce, exactly."""

import sys
from pathlib import Path

import pytest

TOY = Path(__file__).parent.parent / "examples" / "two_route_toy"
sys.path.insert(0, str(TOY))

from pipeline import pipeline

from routeval import Harness, render_terminal


@pytest.fixture(scope="module")
def run():
    return Harness(
        pipeline, auto_routes=["cheap"], escalation_routes=["escalate"], runs_dir=None
    ).run(TOY / "golden.jsonl")


def test_headline(run):
    a = run["aggregates"]
    assert a["attempted"] == 20
    assert a["errors"] == 1  # the SYSTEM OVERLOAD item, dead-lettered
    assert a["accuracy_attempted"] == pytest.approx(0.80)


def test_per_route(run):
    pr = run["aggregates"]["per_route"]
    assert pr["cheap"]["n"] == 13  # includes a correct answer with mismatched policy route
    assert pr["escalate"]["n"] == 6
    assert pr["[unknown route]"]["n"] == 1


def test_economics(run):
    e = run["aggregates"]["economics"]
    assert e["total_cost_usd"] == pytest.approx(0.0613)
    assert e["cost_per_correct_usd"] == pytest.approx(0.0613 / 16)
    assert e["deflection_rate"] == pytest.approx(0.65)
    assert e["auto_routes"] == ["cheap"]


def test_routing_and_lucky_hit(run):
    r = run["aggregates"]["routing"]
    assert r["n_labelled"] == 20
    assert r["grid"] == {
        "route_right_verdict_right": 15,
        "route_right_verdict_wrong": 3,
        "route_wrong_verdict_right": 1,  # warranty question: correct answer, different route label
        "route_wrong_verdict_wrong": 1,  # the dead-lettered item
    }
    assert r["lucky_hit_rate"] == pytest.approx(0.05)
    assert r["escalation_routes"] == ["escalate"]
    assert r["escalation_precision"] == pytest.approx(1.0)
    assert r["escalation_recall"] == pytest.approx(6 / 7)


def test_terminal_report_renders_the_story(run):
    text = render_terminal(run)
    for needle in (
        "correct answer / wrong route",
        "cost per CORRECT",
        "DEAD-LETTERED",
        "deflection rate",
        "escalation_recall",
    ):
        assert needle in text
