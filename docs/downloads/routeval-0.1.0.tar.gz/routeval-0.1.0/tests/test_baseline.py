"""CI regression failures reproduced on real artifacts, not invented aggregate dicts."""

import copy

import pytest

from routeval import Decision, Harness
from routeval.baseline import compare, render_comparison


def make_run(accuracy=0.8, cpc=0.001, errors=0, escalate=True, unknown=False):
    rows = [
        {"input": n, "expected": "ok", "expected_route": "cheap" if n < 50 else "escalate"}
        for n in range(100)
    ]

    def pipeline(n):
        return Decision(
            answer="ok" if n < round(accuracy * 100) else "wrong",
            route="escalate" if escalate and n >= 50 else "cheap",
            cost_usd=None if unknown else cpc * accuracy,
            error="known failed call" if n < errors else None,
        )

    return Harness(
        pipeline, auto_routes=["cheap"], escalation_routes=["escalate"], runs_dir=None
    ).run(rows)


def test_identical_runs_pass():
    assert compare(make_run(), make_run())["exit_code"] == 0


def test_accuracy_drop_and_tolerance():
    assert "accuracy_attempted" in compare(make_run(accuracy=0.7), make_run())["regressions"]
    assert compare(make_run(accuracy=0.79), make_run())["exit_code"] == 0


def test_cost_regression_is_relative_or_absolute_from_zero():
    assert "cost_per_correct_usd" in compare(make_run(cpc=0.002), make_run())["regressions"]
    assert compare(make_run(cpc=0.0011), make_run())["exit_code"] == 0
    assert compare(make_run(cpc=1), make_run(cpc=0))["exit_code"] == 1
    assert (
        compare(make_run(cpc=0.001), make_run(cpc=0), {"cost_zero_absolute_usd": 0.002})[
            "exit_code"
        ]
        == 0
    )


def test_escalation_disappearing_is_a_regression():
    current = make_run(escalate=False)
    assert current["aggregates"]["routing"]["escalation_recall"] == 0
    block = compare(current, make_run())
    assert "escalation_recall" in block["regressions"]
    assert "routing_accuracy" in block["regressions"]
    assert "correct_answer_wrong_route_rate" in block["regressions"]
    assert block["exit_code"] == 1


def test_new_error_is_a_regression():
    assert "errors" in compare(make_run(errors=1), make_run())["regressions"]


def test_removed_metric_invalidates_comparison():
    current = make_run()
    del current["aggregates"]["routing"]
    block = compare(current, make_run())
    assert block["exit_code"] == 3
    assert "aggregates do not match" in " ".join(block["issues"])


def test_unknown_cost_invalidates_comparison():
    block = compare(make_run(unknown=True), make_run())
    assert block["exit_code"] == 3
    assert "incomplete cost" in " ".join(block["issues"])


@pytest.mark.parametrize(
    "field", ["scorer", "route_policy", "cost_basis", "pricing_file", "golden_set"]
)
def test_changed_measurement_contract_rejected(field):
    current, baseline = make_run(), make_run()
    if field in ("pricing_file", "golden_set"):
        current["manifest"][field]["sha256"] = "different"
    elif field == "cost_basis":
        current["manifest"][field] = "replay"
    elif field == "scorer":
        current["manifest"][field]["version"] = "changed"
    else:
        current["manifest"][field]["auto_routes"] = []
    assert compare(current, baseline)["exit_code"] == 3


def test_legacy_or_summary_artifact_cannot_pass():
    current = make_run()
    legacy = copy.deepcopy(current)
    legacy["schema_version"] = "0"
    assert compare(current, legacy)["exit_code"] == 3
    del legacy["items"]
    legacy["schema_version"] = "1"
    assert compare(current, legacy)["exit_code"] == 3


def test_invalid_tolerance_rejected():
    with pytest.raises(ValueError, match="unknown tolerance"):
        compare(make_run(), make_run(), {"typo": 0.1})
    with pytest.raises(ValueError, match="nonnegative"):
        compare(make_run(), make_run(), {"accuracy_attempted": -1})


def test_render_marks_regressions():
    text = render_comparison(compare(make_run(accuracy=0.5), make_run()))
    assert "REGRESSION" in text and "exit 1" in text


def test_malformed_manifest_is_invalid_instead_of_crashing():
    block = compare(
        {"schema_version": "1", "manifest": []}, {"schema_version": "1", "manifest": []}
    )
    assert block["exit_code"] == 3


def test_zero_correct_answers_cannot_silently_pass_cost_comparison():
    block = compare(make_run(accuracy=0), make_run())
    assert block["exit_code"] == 3
    assert "accuracy_attempted" in block["regressions"]
    assert "required metric unavailable: cost_per_correct_usd" in block["issues"]
