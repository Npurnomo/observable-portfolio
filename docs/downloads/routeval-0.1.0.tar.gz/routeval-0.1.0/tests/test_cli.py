"""CLI: the ten-minute experience must work from a cold directory."""

import json
import subprocess
import sys

import pytest

from routeval.cli import _load_callable, build_parser


def routeval(*args, cwd):
    return subprocess.run(
        [sys.executable, "-m", "routeval.cli", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
        check=False,
    )


def test_init_then_run_needs_no_api_key(tmp_path):
    init = routeval("init", "demo", cwd=tmp_path)
    assert init.returncode == 0
    assert (tmp_path / "demo" / "pipeline.py").exists()
    assert (tmp_path / "demo" / "golden.jsonl").exists()

    run = routeval(
        "run",
        "--config",
        "demo/routeval.json",
        cwd=tmp_path,
    )
    assert run.returncode == 0, run.stderr
    assert "correct answer / wrong route" in run.stdout
    assert "cost per CORRECT" in run.stdout
    artifacts = list((tmp_path / "runs").glob("run-*.json"))
    assert len(artifacts) == 1
    assert json.loads(artifacts[0].read_text())["schema_version"] == "1"


def test_init_refuses_to_clobber(tmp_path):
    routeval("init", "demo", cwd=tmp_path)
    second = routeval("init", "demo", cwd=tmp_path)
    assert second.returncode == 2 and "refusing to overwrite" in second.stderr
    assert routeval("init", "demo", "--force", cwd=tmp_path).returncode == 0


def test_compare_exits_nonzero_on_regression(tmp_path):
    from routeval import Decision, Harness

    rows = [{"input": "x", "expected": "ok"}, {"input": "y", "expected": "ok"}]
    good = Harness(lambda _: Decision("ok", "cheap", 0.001), runs_dir=None).run(rows)
    bad = Harness(
        lambda value: Decision("wrong" if value == "x" else "ok", "cheap", 0.001),
        runs_dir=None,
    ).run(rows)
    (tmp_path / "good.json").write_text(json.dumps(good))
    (tmp_path / "bad.json").write_text(json.dumps(bad))

    assert routeval("compare", "good.json", "good.json", cwd=tmp_path).returncode == 0
    regressed = routeval("compare", "bad.json", "good.json", cwd=tmp_path)
    assert regressed.returncode == 1 and "REGRESSION" in regressed.stdout


def test_bad_pipeline_spec_is_a_clear_error():
    with pytest.raises(ValueError, match="must look like"):
        _load_callable("no_colon_here")


def test_parser_requires_a_command():
    with pytest.raises(SystemExit):
        build_parser().parse_args([])


def test_bare_quickstart_and_nested_destination(tmp_path):
    assert routeval("init", cwd=tmp_path).returncode == 0
    assert routeval("run", cwd=tmp_path).returncode == 0
    assert routeval("init", "a space/nested", cwd=tmp_path).returncode == 0
    result = routeval("run", "--config", "a space/nested/routeval.json", cwd=tmp_path)
    assert result.returncode == 0, result.stderr


def test_init_preflights_every_file_before_copying(tmp_path):
    destination = tmp_path / "demo"
    destination.mkdir()
    (destination / "golden.jsonl").write_text("keep me")
    assert routeval("init", "demo", cwd=tmp_path).returncode == 2
    assert not (destination / "pipeline.py").exists()
    assert (destination / "golden.jsonl").read_text() == "keep me"


@pytest.mark.parametrize("value", [None, 42, [], {}])
def test_invalid_config_pipeline_has_a_clear_error(tmp_path, value):
    (tmp_path / "routeval.json").write_text(json.dumps({"pipeline": value}))
    result = routeval("run", cwd=tmp_path)
    assert result.returncode == 2
    assert "Traceback" not in result.stderr


def test_cli_quality_gate_unknown_cost_and_pipeline_errors(tmp_path):
    (tmp_path / "golden.jsonl").write_text('{"input":"x","expected":"ok"}\n')
    (tmp_path / "pipeline.py").write_text(
        "from routeval import Decision\ndef pipeline(x): return Decision('ok')\n"
    )
    args = ("run", "--pipeline", "pipeline.py:pipeline", "--golden", "golden.jsonl")
    assert routeval(*args, cwd=tmp_path).returncode == 0
    assert routeval(*args, "--max-cost-per-correct-usd", "1", cwd=tmp_path).returncode == 3
    (tmp_path / "pipeline.py").write_text("def pipeline(x): raise RuntimeError('failure')\n")
    assert routeval(*args, cwd=tmp_path).returncode == 1
    assert routeval(*args, "--allow-errors", cwd=tmp_path).returncode == 0


def test_cli_async_and_dataclass_import(tmp_path):
    (tmp_path / "golden.jsonl").write_text('{"input":"x","expected":"ok"}\n')
    (tmp_path / "pipeline.py").write_text(
        "from dataclasses import dataclass\nfrom routeval import Decision\n"
        "@dataclass\nclass Output:\n    value: str\n"
        "async def pipeline(x): return Decision(Output('ok').value, cost_usd=0)\n"
    )
    result = routeval(
        "run",
        "--pipeline",
        "pipeline.py:pipeline",
        "--golden",
        "golden.jsonl",
        "--min-accuracy",
        "1",
        cwd=tmp_path,
    )
    assert result.returncode == 0, result.stderr
