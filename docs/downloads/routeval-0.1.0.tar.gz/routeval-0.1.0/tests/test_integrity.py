"""Failure stories from the adoption review, with synthetic offline decisions."""

import asyncio
import json
from pathlib import Path

import pytest

from routeval import Decision, Harness, render_terminal
from routeval.artifact import summary
from routeval.baseline import compare

ROWS = [{"id": "one", "input": "hello", "expected": "ok", "expected_route": "human"}]


def test_zero_cost_policy_and_missing_escalation():
    current = Harness(
        lambda _: Decision("ok", "auto", 0),
        auto_routes=["auto"],
        escalation_routes=["human"],
        runs_dir=None,
    ).run(ROWS)
    baseline = Harness(
        lambda _: Decision("ok", "human", 0),
        auto_routes=["auto"],
        escalation_routes=["human"],
        runs_dir=None,
    ).run(ROWS)
    r = current["aggregates"]["routing"]
    assert r["escalation_recall"] == 0
    assert r["escalation_precision"] is None
    assert current["aggregates"]["economics"]["deflection_rate"] == 1
    assert "escalation_recall" in compare(current, baseline)["regressions"]


def test_partial_labels_use_explicit_coverage_and_denominator():
    run = Harness(lambda _: Decision("ok", "auto", 0), runs_dir=None).run(
        ROWS + [{"input": "unlabelled", "expected": "ok"}] * 4
    )
    r = run["aggregates"]["routing"]
    assert r["label_coverage"] == 0.2
    assert r["correct_answer_wrong_route_rate"] == r["lucky_hit_rate"] == 1


@pytest.mark.parametrize("result", [0.01, 0, 1, "false", {"pass": False}, None])
def test_scorer_must_return_boolean_without_losing_cost(result):
    run = Harness(
        lambda _: Decision("ok", "auto", 0.3), scorer=lambda e, a: result, runs_dir=None
    ).run(ROWS)
    item = run["items"][0]
    assert item["answer"] == "ok" and item["route"] == "auto" and item["cost_usd"] == 0.3
    assert item["error_stage"] == "scorer" and item["correct"] is False
    assert run["manifest"]["status"] == "measurement_failed"


def test_scorer_exception_does_not_abort_remaining_cases(tmp_path):
    def scorer(expected, answer):
        raise TimeoutError("judge timeout")

    run = Harness(
        lambda _: Decision("ok", "auto", 0.3), scorer=scorer, scorer_version="1", runs_dir=tmp_path
    ).run(ROWS * 1 + [{"input": "next", "expected": "ok"}])
    assert run["aggregates"]["attempted"] == run["aggregates"]["measurement_errors"] == 2
    assert run["aggregates"]["economics"]["total_cost_usd"] == pytest.approx(0.6)
    assert json.loads(Path(run["manifest"]["artifact_path"]).read_text()) == run


@pytest.mark.parametrize("cost", [-1, float("nan"), float("inf"), True, "0.1"])
def test_invalid_costs_are_visible_validation_failures(cost):
    run = Harness(lambda _: Decision("ok", "auto", cost), runs_dir=None).run(ROWS)
    assert run["items"][0]["error_stage"] == "validation"
    assert run["aggregates"]["economics"]["cost_per_correct_usd"] is None


@pytest.mark.parametrize("tokens", [-1, 1.2, True])
def test_invalid_tokens_preserve_explicit_booked_cost(tokens):
    run = Harness(lambda _: Decision("ok", "auto", 0.2, tokens_in=tokens), runs_dir=None).run(ROWS)
    assert run["items"][0]["cost_usd"] == 0.2
    assert run["items"][0]["error_stage"] == "validation"


def test_unknown_cost_is_not_free():
    run = Harness(lambda _: Decision("ok", "auto"), runs_dir=None).run(ROWS)
    e = run["aggregates"]["economics"]
    assert not e["cost_complete"] and e["total_cost_usd"] is None
    assert e["known_cost_usd"] == 0 and e["cost_per_correct_usd"] is None
    assert "incomplete" in render_terminal(run)


def test_known_failed_cost_is_booked():
    run = Harness(
        lambda _: Decision(None, "human", 0.2, error="paid call failed"), runs_dir=None
    ).run(ROWS)
    assert run["aggregates"]["errors"] == 1
    assert run["aggregates"]["economics"]["total_cost_usd"] == 0.2
    assert run["items"][0]["error_stage"] == "pipeline"


def test_complete_artifacts_are_unique_and_include_baseline(tmp_path):
    h = Harness(lambda _: Decision("ok", "auto", 0), runs_dir=tmp_path)
    first = h.run(ROWS)
    second = h.run(ROWS, baseline=first)
    assert len(list(tmp_path.glob("*.json"))) == 2
    assert first["manifest"]["artifact_path"] != second["manifest"]["artifact_path"]
    saved = json.loads(Path(second["manifest"]["artifact_path"]).read_text())
    assert saved == second
    assert saved["baseline"]["exit_code"] == 0


def test_incompatible_baseline_rejected_before_pipeline_calls():
    previous = Harness(lambda _: Decision("ok", "auto", 0), runs_dir=None).run(ROWS)
    calls = []
    with pytest.raises(ValueError, match="golden_set"):
        Harness(lambda x: calls.append(x), runs_dir=None).run(
            [{"input": "different", "expected": "ok"}], baseline=previous
        )
    assert calls == []


def test_pricing_contents_change_hash_and_reject_baseline(tmp_path):
    first, second = tmp_path / "a.json", tmp_path / "b.json"
    first.write_text('{"demo":{"in_per_1m":1,"out_per_1m":0}}')
    second.write_text('{"demo":{"in_per_1m":100,"out_per_1m":0}}')
    pipeline = lambda _: Decision("ok", "auto", model="demo", tokens_in=1_000_000)
    a = Harness(pipeline, pricing_path=str(first), runs_dir=None).run(ROWS)
    b = Harness(pipeline, pricing_path=str(second), runs_dir=None).run(ROWS)
    assert a["manifest"]["config_hash"] != b["manifest"]["config_hash"]
    assert a["manifest"]["pricing_file"]["sha256"] != b["manifest"]["pricing_file"]["sha256"]
    assert compare(b, a)["exit_code"] == 3


def test_summary_omits_sensitive_contents_and_identifiers():
    secret = "SYNTHETIC-CUSTOMER-TEXT"
    run = Harness(
        lambda x: Decision(x, "auto", 0, stages={"lookup": {"text": secret}}),
        echo_inputs=True,
        runs_dir=None,
    ).run([{"id": secret, "input": secret, "expected": secret}], note=secret)
    output = summary(run)
    assert secret not in json.dumps(output)
    assert "items" not in output and "git_sha" not in output["manifest"]
    assert "input_hash" not in json.dumps(output)
    assert compare(output, run)["exit_code"] == 3


def test_async_pipeline_and_scorer_sequentially():
    visited = []

    async def pipeline(x):
        visited.append(x)
        await asyncio.sleep(0)
        return Decision("ok", "auto", 0)

    async def scorer(expected, answer):
        return expected == answer

    h = Harness(pipeline, scorer=scorer, scorer_version="1", runs_dir=None)
    with pytest.raises(ValueError, match="arun"):
        h.run(ROWS)
    run = asyncio.run(h.arun(ROWS + [{"input": "second", "expected": "ok"}]))
    assert visited == ["hello", "second"]
    assert run["aggregates"]["accuracy_attempted"] == 1


@pytest.mark.parametrize(
    "rows",
    [
        [],
        [{"expected": "x"}],
        [{"input": "x"}],
        [{"id": "same", "input": "a", "expected": "x"}] * 2,
    ],
)
def test_bad_golden_set_is_rejected_before_execution(rows):
    with pytest.raises(ValueError):
        Harness(lambda _: pytest.fail("must not execute"), runs_dir=None).run(rows)


def test_overlapping_route_roles_rejected():
    with pytest.raises(ValueError, match="disjoint"):
        Harness(lambda _: Decision("ok"), auto_routes=["same"], escalation_routes=["same"])


@pytest.mark.parametrize("answer", [("ok",), {1: "ok"}])
def test_python_only_answer_shapes_cannot_change_in_saved_artifact(answer, tmp_path):
    run = Harness(lambda _: Decision(answer, "auto", 0.2), runs_dir=tmp_path).run(ROWS)
    assert run["items"][0]["error_stage"] == "validation"
    assert run["items"][0]["cost_usd"] == 0.2
    assert json.loads(Path(run["manifest"]["artifact_path"]).read_text()) == run
