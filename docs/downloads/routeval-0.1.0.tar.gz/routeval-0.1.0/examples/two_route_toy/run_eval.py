"""Run the toy eval: python examples/two_route_toy/run_eval.py (no API keys)."""

from pathlib import Path

from pipeline import pipeline

from routeval import Harness, render_terminal

if __name__ == "__main__":
    harness = Harness(
        pipeline,
        auto_routes=["cheap"],
        escalation_routes=["escalate"],
        runs_dir=Path(__file__).parent / "runs",
    )
    run = harness.run(Path(__file__).parent / "golden.jsonl", note="two-route toy")
    print(render_terminal(run))
