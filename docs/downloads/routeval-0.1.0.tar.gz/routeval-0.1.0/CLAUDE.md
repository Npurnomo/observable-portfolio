# CLAUDE.md — routeval

## What this project is

A small, sharp OSS eval tool for *routed* AI pipelines (cascades, abstains,
handoffs, caches). The wedge is routing economics — cost-per-correct-decision,
automatic completion, policy-label agreement — NOT generic output scoring. Planning
record: Confluence page 19365890 ("Routeval — Problem Statement and v0.1
Plan"). Current acceptance criteria and metric meanings live in README.md and docs/run-schema.md. The launch essay supplies the origin story.

## Invariants — do not violate

1. **The versioned `run.json` schema is the real API** (docs/run-schema.md).
   Users, CI, and coding agents script against it. Any schema change bumps
   `schema_version` and updates the doc in the same commit.
2. **Every metric lives in `metrics.py`, defined once, with a docstring**
   stating what it means and what it needs (tier 1/2/3). Renderers never
   compute; they render.
3. **Report renderers are pure functions of the run artifact.** Terminal, JSON,
   HTML all consume the same `run.json` dict. No renderer touches the network
   or the user's pipeline.
4. **No silent drops.** Pipeline exceptions become dead-lettered items counted
   in the attempted denominator and listed in the report. Never retry silently,
   never exclude.
5. **Accuracy over attempted, not successful.**
6. **Zero-dependency core** (stdlib only). Any future extra must be optional. The zero-key hello world must work offline.
7. **Route roles are declared, never inferred from cost. Pricing is data, not code**: `economics.py` reads a bundled, user-
   overridable pricing file. Never hardcode a model price in logic.
8. **Tiered metrics degrade gracefully**: missing `expected_route` labels must
   never error — tier-2 sections simply don't render.
9. **The word "framework" never appears in docs, README, or marketing.**
10. **New metrics require a documented failure story** (a real bug the metric
    would have caught) in the PR description. This is the scope firewall.

## Scope guard (v0.1)

IN: harness run loop, Decision contract, tier 1+2 metrics, pricing file,
exact/normalized/contains/callable scorers + bring-your-own-judge hook,
baseline compare with exit codes, terminal+JSON report, `init` scaffold,
LangGraph *recipe* (docs + ≤30-line helper).
OUT (do not build, even if asked nicely by a TODO): our own LLM judge, judge
calibration, drift, dashboards/servers, response caching, HTML report may
trail launch, counterfactual mode (v0.2).

## Conventions

- Python 3.10+; `ruff` clean; pytest; type hints everywhere.
- Tests never touch the network; the toy pipeline in `examples/two_route_toy`
  doubles as the test fixture.
- Small commits scoped to one task; reference the weekend-plan item.
- src layout: `src/routeval/`. Public names re-exported in `__init__.py`;
  everything else is private.
