# Contributing

Keep the report small and trustworthy:

1. New metrics need a concrete failure story and a definition in `metrics.py`.
2. The [run artifact](docs/run-schema.md) is the API. Breaking changes bump
   `schema_version` and update the contract in the same commit.
3. The core uses only the standard library. Tests never call models or providers.
4. Keep route roles explicit, costs complete or visibly unknown, and errors in
   attempted denominators. Renderers read the artifact without recomputing it.

## Development

```sh
python -m pip install -e '.[dev]'
python -m pytest
ruff check .
ruff format --check .
```

Use a minimal **synthetic** reproducer for bugs. Full run artifacts can contain
private expected answers, outputs, and errors. Review them before attaching;
`routeval summary` removes item contents but cannot reproduce all item bugs.

## Release verification

```sh
python -m pip install build twine
python -m build
python -m twine check dist/routeval-0.1.0-py3-none-any.whl dist/routeval-0.1.0.tar.gz
python scripts/verify_distribution.py dist/routeval-0.1.0-py3-none-any.whl
```

The installed check creates a clean temporary environment, installs only the
wheel with no network or dependencies, and verifies the offline quickstart,
five-case wrapper, compatible baseline and regression exits, summary, templates,
and installed version. Also build a wheel from the sdist. The CI workflow runs
source tests on supported Python versions and installed checks on Linux,
Windows, and macOS; a local pass does not imply remote CI has run.

Before public upload, configure the real source and issue URLs, authenticate
GitHub and PyPI, run the installed checks, and confirm the public install gets
the functional harness. Document publication separately from build completion.
