"""The pipeline's answer, policy route and whole-decision cost."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from numbers import Real
from typing import Any


@dataclass(frozen=True)
class Decision:
    answer: Any
    route: str | None = "default"
    cost_usd: float | None = None
    model: str | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    stages: dict[str, dict[str, Any]] = field(default_factory=dict)
    # Return a failed decision when its route/cost are known. An exception
    # has unknown cost; the harness never invents a zero-cost failure.
    error: str | None = None


def nonnegative_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a finite, nonnegative number")
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"{name} must be a finite, nonnegative number")
    return result


def route_names(names: Any, name: str) -> tuple[str, ...]:
    if isinstance(names, str):
        raise TypeError(f"{name} must be a sequence of route names, not a string")
    values = tuple(names)
    if any(not isinstance(v, str) or not v.strip() for v in values):
        raise ValueError(f"{name} requires nonempty string route names")
    return tuple(sorted(set(values)))


def validate_json_value(value: Any) -> None:
    """Reject Python-only values that would silently change in the saved artifact."""
    encoded = json.dumps(value, allow_nan=False)
    if json.loads(encoded) != value:
        raise ValueError("values must survive JSON unchanged; use lists and string object keys")


def validate_decision(decision: Decision) -> None:
    if decision.error is not None and (
        not isinstance(decision.error, str) or not decision.error.strip()
    ):
        raise ValueError("Decision.error must be a nonempty string or None")
    if decision.route is None:
        if decision.error is None:
            raise ValueError("successful decisions require a route")
    elif not isinstance(decision.route, str) or not decision.route.strip():
        raise ValueError("Decision.route must be a nonempty string")
    if decision.cost_usd is not None:
        nonnegative_number(decision.cost_usd, "Decision.cost_usd")
    for name in ("tokens_in", "tokens_out"):
        value = getattr(decision, name)
        if type(value) is not int or value < 0:
            raise ValueError(f"Decision.{name} must be a nonnegative integer")
    if decision.model is not None and (
        not isinstance(decision.model, str) or not decision.model.strip()
    ):
        raise ValueError("Decision.model must be a nonempty string or None")
    if not isinstance(decision.stages, dict) or any(
        not isinstance(k, str) or not isinstance(v, dict) for k, v in decision.stages.items()
    ):
        raise ValueError("Decision.stages must map stage names to dictionaries")
    validate_json_value({"answer": decision.answer, "stages": decision.stages})


def validate_golden_row(row: dict, index: int) -> dict:
    if not isinstance(row, dict):
        raise TypeError(f"golden row {index} must be an object")
    for key in ("input", "expected"):
        if key not in row:
            raise ValueError(f"golden row {index} is missing required key {key!r}")
    row = {**row, "id": row.get("id", f"g-{index:04d}")}
    if not isinstance(row["id"], str) or not row["id"].strip():
        raise ValueError(f"golden row {index} id must be a nonempty string")
    for key in ("expected_route", "tier"):
        if row.get(key) is not None and (not isinstance(row[key], str) or not row[key].strip()):
            raise ValueError(f"golden row {index} {key} must be a nonempty string or null")
    validate_json_value(row)
    return row
