"""Scorers: (expected, answer) -> bool. Deliberately few.

routeval's job is routing economics, not a metric library — bring your own
judge by passing any callable with this signature to the Harness (an LLM
judge from DeepEval, a regex, your own function; we don't care and never
call the network ourselves).
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

Scorer = Callable[[Any, Any], bool]


def exact(expected: Any, answer: Any) -> bool:
    """Strict equality."""
    return expected == answer


def normalized(expected: Any, answer: Any) -> bool:
    """Case-insensitive, whitespace-collapsed string equality (the default)."""
    return _norm(expected) == _norm(answer)


def contains(expected: Any, answer: Any) -> bool:
    """Normalized expected appears within the normalized answer."""
    return _norm(expected) in _norm(answer)


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value)).strip().casefold()
