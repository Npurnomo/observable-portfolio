"""routeval — evals for AI pipelines that route.

Answer quality, policy agreement, and cost per correct decision.
The run.json artifact schema (docs/run-schema.md) is the real API.
"""

__version__ = "0.1.0"

from routeval.decision import Decision
from routeval.harness import Harness
from routeval.report import render_terminal
from routeval.scorers import contains, exact, normalized

__all__ = [
    "Decision",
    "Harness",
    "__version__",
    "contains",
    "exact",
    "normalized",
    "render_terminal",
]
