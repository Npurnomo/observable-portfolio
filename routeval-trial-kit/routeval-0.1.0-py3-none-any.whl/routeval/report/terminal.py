"""Pure projection of schema-1 metrics and its saved comparison."""

from __future__ import annotations

from routeval.baseline import render_comparison


def render_terminal(run: dict) -> str:
    manifest, aggregates = run["manifest"], run["aggregates"]
    lines = [
        f"routeval run — {manifest['started_at']} (schema v{run['schema_version']})",
        f"golden: {manifest['golden_set']['n']} items · config {manifest['config_hash'][:8]}",
        f"status: {manifest['status']}",
        "",
        (
            f"ACCURACY over attempted   {aggregates['accuracy_attempted']:.1%}"
            f"   ({aggregates['attempted']} attempted · {aggregates['errors']} errors)"
        ),
        "",
        "PER ROUTE",
        f"  {'route':<20}{'n':>5}{'share':>8}{'accuracy':>10}{'known cost $':>15}{'p95 ms':>10}",
    ]
    for route, values in aggregates["per_route"].items():
        lines.append(
            f"  {route:<20}{values['n']:>5}{values['share']:>8.0%}{values['accuracy']:>10.1%}"
            f"{values['known_cost_usd']:>15.6f}{values['p95_latency_ms']:>10.1f}"
        )
    economics = aggregates["economics"]
    lines.extend(["", "ECONOMICS"])
    if economics["cost_complete"]:
        lines.append(f"  total cost            ${economics['total_cost_usd']:.6f}")
    else:
        lines.append(f"  known cost subtotal   ${economics['known_cost_usd']:.6f} (incomplete)")
        lines.append(
            f"  unknown costs         {economics['unknown_cost_n']} item(s); cost gates unavailable"
        )
    cpc = economics["cost_per_correct_usd"]
    lines.append("  cost per CORRECT      " + (f"${cpc:.8f}" if cpc is not None else "unavailable"))
    lines.append(f"  cost basis            {manifest['cost_basis']} (self-reported/estimated)")
    if economics["deflection_rate"] is not None:
        lines.append(
            f"  deflection rate       {economics['deflection_rate']:.1%} (declared automatic routes)"
        )
    else:
        lines.append("  deflection rate       unavailable; declare auto_routes")
    if "routing" in aggregates:
        routing = aggregates["routing"]
        lines.extend(
            [
                "",
                f"ROUTING ({routing['n_labelled']} labelled; {routing['label_coverage']:.1%} coverage)",
            ]
        )
        lines.append(f"  routing accuracy      {routing['routing_accuracy']:.1%}")
        for name, count in routing["grid"].items():
            lines.append(f"  {name:<36}{count:>6}")
        lines.append(
            f"  correct answer / wrong route  {routing['correct_answer_wrong_route_rate']:.1%}"
            " of labelled items (legacy lucky_hit_rate)"
        )
        lines.append(f"  escalation routes     {routing['escalation_routes']}")
        for key in ("escalation_precision", "escalation_recall"):
            value = routing[key]
            lines.append(f"  {key:<24}" + (f"{value:.1%}" if value is not None else "unavailable"))
    if "stages" in aggregates:
        lines.extend(["", "STAGES (user-scored)"])
        for name, stage in aggregates["stages"].items():
            lines.append(f"  {name:<20}{stage['accuracy']:>8.1%} (n={stage['n']})")
    errors = [item for item in run["items"] if item["error"] is not None]
    if errors:
        lines.extend(
            ["", f"DEAD-LETTERED ({aggregates['errors']}) — counted in attempted accuracy:"]
        )
        for item in errors[:10]:
            lines.append(f"  {item['id']} [{item['error_stage']}]: {item['error']}")
    if "baseline" in run:
        lines.extend(["", render_comparison(run["baseline"])])
    if manifest.get("artifact_path"):
        lines.extend(["", f"artifact: {manifest['artifact_path']}"])
    return "\n".join(lines)
