"""Strict JSON input and atomic persistence of the complete run artifact."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "1"


def _reject_constant(value: str) -> None:
    raise ValueError(f"nonfinite JSON number: {value}")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    obj: dict = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def read_json(text: str) -> Any:
    return json.loads(text, parse_constant=_reject_constant, object_pairs_hook=_unique_object)


def digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def load_run(path: str | Path) -> dict:
    run = read_json(Path(path).read_text(encoding="utf-8"))
    if not isinstance(run, dict):
        raise TypeError("run artifact must be a JSON object")
    return run


def summary(run: dict) -> dict:
    """Remove item contents, IDs, hashes, paths and free-form manifest fields.

    Aggregate route/stage names remain. Review those before public sharing.
    A summary is not a baseline artifact because it intentionally has no items.
    """
    if run.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("summary requires schema 1; regenerate a legacy run")
    manifest = run["manifest"]
    output = {
        "schema_version": SCHEMA_VERSION,
        "summary_only": True,
        "manifest": {
            key: manifest[key] for key in ("harness_version", "started_at", "finished_at", "status")
        },
        "aggregates": copy.deepcopy(run["aggregates"]),
    }
    if "baseline" in run:
        output["baseline"] = {
            key: copy.deepcopy(run["baseline"][key])
            for key in ("status", "exit_code", "deltas", "regressions")
        }
    return output


def write_run(run: dict, path: Path) -> None:
    """Serialize before touching disk, then replace atomically on the same volume."""
    payload = json.dumps(run, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=".routeval-", delete=False
        ) as file:
            temporary = file.name
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None:
            Path(temporary).unlink(missing_ok=True)
