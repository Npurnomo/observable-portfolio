"""Resolve user-reported total cost or an explicitly estimated token cost."""

from __future__ import annotations

from importlib import resources

from routeval.artifact import read_json
from routeval.decision import Decision, nonnegative_number


def load_pricing(path: str | None = None) -> dict:
    if path is None:
        text = resources.files("routeval").joinpath("pricing.json").read_text()
    else:
        with open(path, encoding="utf-8") as file:
            text = file.read()
    pricing = read_json(text)
    if not isinstance(pricing, dict):
        raise TypeError("pricing must be a JSON object")
    for model, rates in pricing.items():
        if model.startswith("_"):
            continue
        if not isinstance(rates, dict):
            raise TypeError(f"pricing for {model!r} must be an object")
        for name in ("in_per_1m", "out_per_1m"):
            if name not in rates:
                raise ValueError(f"pricing for {model!r} is missing {name}")
            nonnegative_number(rates[name], f"{model}.{name}")
    return pricing


def resolve_cost(decision: Decision, pricing: dict) -> float | None:
    """Explicit whole-decision cost wins. Unknown means None, never free."""
    if decision.cost_usd is not None:
        return nonnegative_number(decision.cost_usd, "Decision.cost_usd")
    if decision.model and decision.model in pricing and not decision.model.startswith("_"):
        rates = pricing[decision.model]
        cost = (
            decision.tokens_in / 1_000_000 * rates["in_per_1m"]
            + decision.tokens_out / 1_000_000 * rates["out_per_1m"]
        )
        return nonnegative_number(cost, "estimated cost")
    return None
