"""Fail closed on incomparable artifacts or unavailable required measurements."""

from __future__ import annotations

from typing import Any

from routeval import metrics
from routeval.artifact import SCHEMA_VERSION, digest
from routeval.decision import nonnegative_number, route_names

WATCHED = {
    "accuracy_attempted": (("accuracy_attempted",), "down", 0.02),
    "cost_per_correct_usd": (("economics", "cost_per_correct_usd"), "up", 0.25),
    "correct_answer_wrong_route_rate": (("routing", "correct_answer_wrong_route_rate"), "up", 0.05),
    "routing_accuracy": (("routing", "routing_accuracy"), "down", 0.05),
    "escalation_recall": (("routing", "escalation_recall"), "down", 0.05),
    "errors": (("errors",), "up", 0.0),
}


def validate_tolerances(tolerances: dict | None) -> dict[str, float]:
    values = {**{key: value[2] for key, value in WATCHED.items()}, "cost_zero_absolute_usd": 0.0}
    if tolerances is not None:
        if not isinstance(tolerances, dict):
            raise ValueError("tolerances must be a JSON object")
        for key, value in tolerances.items():
            if key not in values:
                raise ValueError(f"unknown tolerance {key!r}; choose from {sorted(values)}")
            values[key] = nonnegative_number(value, f"tolerance {key}")
    return values


def compatibility_issues(run: dict, baseline: dict) -> list[str]:
    """Check metadata before calling a user's pipeline; changed code is allowed."""
    issues: list[str] = []
    for label, data in (("current", run), ("baseline", baseline)):
        if not isinstance(data, dict) or data.get("schema_version") != SCHEMA_VERSION:
            issues.append(f"{label}: requires schema {SCHEMA_VERSION}; regenerate legacy artifacts")
            continue
        manifest = data.get("manifest")
        if not isinstance(manifest, dict):
            issues.append(f"{label}: missing manifest")
            continue
        for key in ("golden_set", "pricing_file", "scorer", "route_policy", "cost_basis"):
            if key not in manifest:
                issues.append(f"{label}: missing manifest.{key}")
        scorer = manifest.get("scorer", {})
        if not isinstance(scorer, dict) or any(
            not isinstance(scorer.get(key), str) or not scorer[key].strip()
            for key in ("id", "version")
        ):
            issues.append(f"{label}: comparison requires a versioned scorer")
        policy = manifest.get("route_policy")
        try:
            if not isinstance(policy, dict):
                raise TypeError("route_policy must be an object")
            auto = route_names(policy["auto_routes"], "auto_routes")
            escalation = route_names(policy["escalation_routes"], "escalation_routes")
            if set(auto) & set(escalation):
                raise ValueError("automatic and escalation routes must be disjoint")
        except (KeyError, TypeError, ValueError) as exc:
            issues.append(f"{label}: invalid route policy: {exc}")
        basis = manifest.get("cost_basis")
        if not isinstance(basis, str) or not basis.strip():
            issues.append(f"{label}: invalid cost basis")
    if issues:
        return issues
    current, previous = run["manifest"], baseline["manifest"]
    for key in ("scorer", "route_policy", "cost_basis"):
        if current[key] != previous[key]:
            issues.append(f"incompatible {key}")
    for key in ("golden_set", "pricing_file"):
        if not isinstance(current[key], dict) or not isinstance(previous[key], dict):
            issues.append(f"invalid {key} metadata")
        elif not current[key].get("sha256") or current[key]["sha256"] != previous[key].get(
            "sha256"
        ):
            issues.append(f"different {key} sha256")
    return issues


def validate_run(run: dict) -> list[str]:
    """Validate item-derived aggregates, preventing stale/edited totals from gating CI."""
    issues = compatibility_issues(run, run)
    if issues:
        return issues
    try:
        items = run["items"]
        if not isinstance(items, list) or not items:
            return ["artifact needs at least one attempted item"]
        ids = set()
        for item in items:
            if not isinstance(item, dict) or type(item.get("correct")) is not bool:
                return ["invalid item correctness"]
            if not isinstance(item.get("id"), str) or not item["id"].strip():
                return ["invalid item ID"]
            for key in ("route", "expected_route"):
                value = item[key]
                if value is not None and (not isinstance(value, str) or not value.strip()):
                    return [f"invalid item {key}"]
            if item["error"] is None:
                if item["route"] is None or item["error_stage"] is not None:
                    return ["successful item requires a route and no error stage"]
            elif not isinstance(item["error"], str) or item["error_stage"] not in (
                "pipeline",
                "scorer",
                "validation",
            ):
                return ["invalid item error"]
            if item.get("stages") is not None and not isinstance(item["stages"], dict):
                return ["invalid item stages"]
            if item["id"] in ids:
                return ["duplicate item IDs"]
            ids.add(item["id"])
            if item["error"] is not None and item["correct"]:
                return ["errored item cannot be correct"]
            if item["cost_usd"] is not None:
                nonnegative_number(item["cost_usd"], "item cost")
            nonnegative_number(item["latency_ms"], "item latency")
        if len(items) != run["manifest"]["golden_set"]["n"]:
            issues.append("item count differs from golden manifest")
        expected = metrics.aggregate(items, run["manifest"]["route_policy"])
        if digest(expected) != digest(run["aggregates"]):
            issues.append("aggregates do not match recorded items")
        if expected["measurement_errors"]:
            issues.append("run contains scorer or decision validation errors")
        if run["manifest"].get("status") != "complete":
            issues.append("run measurement is not complete")
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        issues.append(f"invalid artifact: {exc}")
    return issues


def _dig(aggregates: dict, path: tuple[str, ...]) -> Any:
    node = aggregates
    for key in path:
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    return node


def compare(run: dict, baseline_run: dict, tolerances: dict | None = None) -> dict:
    """Rates use absolute tolerances; cost uses relative, or absolute from zero.

    Missing costs invalidate a cost comparison. Null precision with zero
    escalations is legitimate; null recall is legitimate only with no required
    escalation cases. Schema 0 is readable JSON but cannot be used as a baseline.
    """
    tol = validate_tolerances(tolerances)
    issues = compatibility_issues(run, baseline_run)
    issues.extend(f"current: {issue}" for issue in validate_run(run))
    issues.extend(f"baseline: {issue}" for issue in validate_run(baseline_run))
    deltas: dict[str, dict] = {}
    regressions: list[str] = []
    if not issues:
        for label, data in (("current", run), ("baseline", baseline_run)):
            if not data["aggregates"]["economics"]["cost_complete"]:
                issues.append(f"{label}: incomplete cost; supply whole-decision costs")
        for name, (path, direction, _) in WATCHED.items():
            now, before = _dig(run["aggregates"], path), _dig(baseline_run["aggregates"], path)
            if now is None and before is None:
                continue
            if now is None or before is None:
                issues.append(f"required metric unavailable: {name}")
                continue
            delta = now - before
            if name == "cost_per_correct_usd":
                worsened = (
                    delta > tol["cost_zero_absolute_usd"]
                    if before == 0
                    else delta / before > tol[name]
                )
            else:
                worsened = delta < -tol[name] if direction == "down" else delta > tol[name]
            deltas[name] = {"before": before, "now": now, "delta": delta}
            if worsened:
                regressions.append(name)
                deltas[name]["regression"] = True
    unique_issues = list(dict.fromkeys(issues))
    manifest = baseline_run.get("manifest") if isinstance(baseline_run, dict) else None
    manifest = manifest if isinstance(manifest, dict) else {}
    return {
        "path": manifest.get("artifact_path"),
        "baseline_run_id": manifest.get("run_id"),
        "baseline_started_at": manifest.get("started_at"),
        "tolerances": tol,
        "deltas": deltas,
        "regressions": regressions,
        "issues": unique_issues,
        "status": "invalid" if unique_issues else ("regression" if regressions else "pass"),
        "exit_code": 3 if unique_issues else (1 if regressions else 0),
    }


def render_comparison(block: dict) -> str:
    lines = ["BASELINE COMPARE"]
    if block["baseline_started_at"]:
        lines.append(f"  vs run of {block['baseline_started_at']}")
    for name, value in block["deltas"].items():
        flag = "  REGRESSION" if value.get("regression") else ""
        lines.append(
            f"  {name:<32}{value['before']:>10.4f} → {value['now']:>10.4f}"
            f"  ({value['delta']:+.4f}){flag}"
        )
    for issue in block["issues"]:
        lines.append(f"  INVALID: {issue}")
    lines.append(f"  → {block['status']} (exit {block['exit_code']})")
    return "\n".join(lines)
