"""Installed quickstart, explicit quality gates and complete baseline artifacts."""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import shlex
import shutil
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from routeval import __version__
from routeval.artifact import load_run, read_json, summary
from routeval.baseline import compare, validate_tolerances
from routeval.decision import nonnegative_number
from routeval.harness import Harness, is_async
from routeval.report import render_terminal
from routeval.scorers import contains, exact, normalized

SCORERS = {"normalized": normalized, "exact": exact, "contains": contains}
CONFIG_KEYS = {
    "pipeline",
    "golden",
    "scorer",
    "auto_routes",
    "escalation_routes",
    "cost_basis",
    "pricing",
    "runs_dir",
    "tolerances",
    "allow_errors",
    "min_accuracy",
    "min_escalation_recall",
    "max_cost_per_correct_usd",
}


def _load_callable(spec: str) -> Callable[[Any], Any]:
    if ":" not in spec:
        raise ValueError(
            "pipeline must look like 'pipeline.py:function' or 'package.module:function'"
        )
    target, function = spec.rsplit(":", 1)
    if target.endswith(".py"):
        path = Path(target).resolve()
        if not path.is_file():
            raise ValueError(f"no such pipeline file: {path}")
        sys.path.insert(0, str(path.parent))
        name = f"_routeval_pipeline_{path.stem}"
        module_spec = importlib.util.spec_from_file_location(name, path)
        if module_spec is None or module_spec.loader is None:
            raise ValueError(f"cannot import pipeline file: {path}")
        module = importlib.util.module_from_spec(module_spec)
        sys.modules[name] = module  # dataclasses and other imports need module identity
        module_spec.loader.exec_module(module)
    else:
        module = importlib.import_module(target)
    value = getattr(module, function, None)
    if not callable(value):
        raise TypeError(f"{target} has no callable {function!r}")
    return value


def cmd_init(args: argparse.Namespace) -> int:
    destination = Path(args.directory).resolve()
    source = Path(__file__).parent / "templates" / "two_route_toy"
    names = ("pipeline.py", "golden.jsonl", "routeval.json")
    conflicts = [str(destination / name) for name in names if (destination / name).exists()]
    if conflicts and not args.force:
        raise ValueError("refusing to overwrite " + ", ".join(conflicts) + " (use --force)")
    destination.mkdir(parents=True, exist_ok=True)
    for name in names:
        shutil.copy(source / name, destination / name)
    print(
        f"scaffolded {destination}\n\n"
        f"next: routeval run --config {shlex.quote(str(destination / 'routeval.json'))}\n"
        "No API key needed. The demo deliberately contains one failure; its config allows errors."
    )
    return 0


def _options(args: argparse.Namespace) -> dict[str, Any]:
    config_path = Path(args.config) if args.config else None
    if config_path is None and args.pipeline is None and args.golden is None:
        for path in (Path("routeval.json"), Path("routeval_example/routeval.json")):
            if path.is_file():
                config_path = path
                break
    config: dict = {}
    if config_path is not None:
        config_path = config_path.resolve()
        config = read_json(config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict) or set(config) - CONFIG_KEYS:
            raise ValueError(f"config requires an object with keys from {sorted(CONFIG_KEYS)}")
        config = dict(config)
        for key in ("pipeline", "golden", "pricing", "runs_dir", "scorer", "cost_basis"):
            if key in config and (not isinstance(config[key], str) or not config[key].strip()):
                raise ValueError(f"config {key} must be a nonempty string")
        for key in ("golden", "pricing", "runs_dir"):
            if config.get(key) is not None:
                config[key] = str(config_path.parent / config[key])
        if config.get("pipeline") and ":" in config["pipeline"]:
            target, function = config["pipeline"].rsplit(":", 1)
            if target.endswith(".py"):
                config["pipeline"] = f"{config_path.parent / target}:{function}"
    options = {
        "scorer": "normalized",
        "auto_routes": [],
        "escalation_routes": [],
        "cost_basis": "deployment",
        "runs_dir": "runs",
        "allow_errors": False,
        **config,
    }
    for key in CONFIG_KEYS - {"tolerances"}:
        value = getattr(args, key, None)
        if value is not None:
            options[key] = value
    if args.tolerances is not None:
        options["tolerances"] = read_json(Path(args.tolerances).read_text(encoding="utf-8"))
    options["tolerances"] = validate_tolerances(options.get("tolerances"))
    if not options.get("pipeline") or not options.get("golden"):
        raise ValueError(
            "run needs --pipeline and --golden, or a routeval.json config; try routeval init"
        )
    if options["scorer"] not in SCORERS:
        raise ValueError(f"scorer must be one of {sorted(SCORERS)}")
    if type(options["allow_errors"]) is not bool:
        raise ValueError("allow_errors must be a boolean")
    for key in ("min_accuracy", "min_escalation_recall", "max_cost_per_correct_usd"):
        if options.get(key) is not None:
            options[key] = nonnegative_number(options[key], key)
            if key.startswith("min_") and options[key] > 1:
                raise ValueError(f"{key} must be between zero and one")
    if options.get("min_escalation_recall") is not None and not options["escalation_routes"]:
        raise ValueError(
            "min_escalation_recall requires --escalation-route or config escalation_routes"
        )
    return options


def _gate(run: dict, options: dict) -> int:
    aggregates = run["aggregates"]
    if aggregates["measurement_errors"]:
        return 3
    if "baseline" in run and run["baseline"]["exit_code"]:
        return run["baseline"]["exit_code"]
    if aggregates["errors"] and not options["allow_errors"]:
        return 1
    checks = (
        ("min_accuracy", aggregates["accuracy_attempted"], "minimum"),
        (
            "min_escalation_recall",
            aggregates.get("routing", {}).get("escalation_recall"),
            "minimum",
        ),
        ("max_cost_per_correct_usd", aggregates["economics"]["cost_per_correct_usd"], "maximum"),
    )
    for key, value, direction in checks:
        limit = options.get(key)
        if limit is None:
            continue
        if value is None:
            print(f"INVALID: {key} cannot be checked with the available measurements")
            return 3
        if value < limit if direction == "minimum" else value > limit:
            print(f"QUALITY GATE FAILED: {key}={limit}, observed {value:.6f}")
            return 1
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    options = _options(args)
    pipeline = _load_callable(options["pipeline"])
    harness = Harness(
        pipeline,
        scorer=SCORERS[options["scorer"]],
        auto_routes=options["auto_routes"],
        escalation_routes=options["escalation_routes"],
        cost_basis=options["cost_basis"],
        echo_inputs=args.echo_inputs,
        pricing_path=options.get("pricing"),
        runs_dir=None if args.no_artifact else options["runs_dir"],
    )
    kwargs = {"note": args.note, "baseline": args.baseline, "tolerances": options["tolerances"]}
    if is_async(pipeline):
        run = asyncio.run(harness.arun(options["golden"], **kwargs))
    else:
        run = harness.run(options["golden"], **kwargs)
    print(render_terminal(run))
    return _gate(run, options)


def cmd_compare(args: argparse.Namespace) -> int:
    tolerances = read_json(Path(args.tolerances).read_text()) if args.tolerances else None
    from routeval.baseline import render_comparison

    block = compare(load_run(args.run), load_run(args.baseline), tolerances)
    print(render_comparison(block))
    return block["exit_code"]


def cmd_summary(args: argparse.Namespace) -> int:
    output = json.dumps(summary(load_run(args.run)), indent=2, allow_nan=False) + "\n"
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output, end="")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="routeval", description="Compare routing policy quality and cost."
    )
    parser.add_argument("--version", action="version", version=f"routeval {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="scaffold an offline two-route example")
    init.add_argument("directory", nargs="?", default="routeval_example")
    init.add_argument("--force", action="store_true")
    init.set_defaults(func=cmd_init)
    run = commands.add_parser("run", help="replay a golden set through your callable")
    for name in ("config", "pipeline", "golden", "baseline", "pricing", "runs-dir", "tolerances"):
        run.add_argument(f"--{name}")
    run.add_argument("--scorer", choices=sorted(SCORERS))
    run.add_argument("--auto-route", action="append", dest="auto_routes")
    run.add_argument("--escalation-route", action="append", dest="escalation_routes")
    run.add_argument("--cost-basis")
    run.add_argument("--allow-errors", action=argparse.BooleanOptionalAction, default=None)
    run.add_argument("--min-accuracy", type=float)
    run.add_argument("--min-escalation-recall", type=float)
    run.add_argument("--max-cost-per-correct-usd", type=float)
    run.add_argument("--no-artifact", action="store_true")
    run.add_argument(
        "--echo-inputs",
        action="store_true",
        help="include raw inputs; artifacts may contain sensitive text",
    )
    run.add_argument("--note", default="")
    run.set_defaults(func=cmd_run)
    comparison = commands.add_parser("compare", help="compare compatible schema-1 run artifacts")
    comparison.add_argument("run")
    comparison.add_argument("baseline")
    comparison.add_argument("--tolerances")
    comparison.set_defaults(func=cmd_compare)
    sharing = commands.add_parser(
        "summary", help="export aggregates without item text or identifiers"
    )
    sharing.add_argument("run")
    sharing.add_argument("--output")
    sharing.set_defaults(func=cmd_summary)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        code = args.func(args)
    except (OSError, ValueError, TypeError, ImportError, KeyError) as exc:
        print(f"routeval: {exc}", file=sys.stderr)
        code = 2
    raise SystemExit(code)


if __name__ == "__main__":
    main()
