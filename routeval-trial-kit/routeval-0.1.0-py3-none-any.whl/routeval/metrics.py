"""Metric definitions for schema 1. Renderers consume these values unchanged.

Failure stories: free paths must not redefine escalation; missing spend must
not look free; partial labels must not become a population-wide claim.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Sequence


def accuracy_attempted(items: list[dict]) -> float:
    """T1. Correct / attempted; all execution and measurement errors count false."""
    return sum(i["correct"] for i in items) / len(items) if items else 0.0


def per_route(items: list[dict]) -> dict[str, dict]:
    """T1. Volume, accuracy, known cost and latency by actual route, including errors."""
    grouped: dict[str, list[dict]] = defaultdict(list)
    for item in items:
        grouped[item["route"] or "[unknown route]"].append(item)
    out = {}
    for route, rows in sorted(grouped.items()):
        costs = [r["cost_usd"] for r in rows if r["cost_usd"] is not None]
        complete = len(costs) == len(rows)
        out[route] = {
            "n": len(rows),
            "share": len(rows) / len(items),
            "accuracy": sum(r["correct"] for r in rows) / len(rows),
            "errors": sum(r.get("error") is not None for r in rows),
            "known_cost_usd": sum(costs),
            "cost_usd": sum(costs) if complete else None,
            "mean_cost_usd": sum(costs) / len(rows) if complete else None,
            "unknown_cost_n": len(rows) - len(costs),
            "p95_latency_ms": _p95([r["latency_ms"] for r in rows]),
        }
    return out


def economics(items: list[dict], auto_routes: Sequence[str] = ()) -> dict:
    """T1. Whole-decision spend / correct answers, only when every cost is known.

    known_cost_usd is a subtotal, not an estimate of missing charges.
    Deflection is successful automatic decisions / attempted, independent of price.
    """
    known = [i["cost_usd"] for i in items if i["cost_usd"] is not None]
    total = sum(known)
    n_correct = sum(i["correct"] for i in items)
    complete = len(known) == len(items)
    return {
        "known_cost_usd": total,
        "total_cost_usd": total if complete else None,
        "cost_per_correct_usd": total / n_correct if complete and n_correct else None,
        "cost_complete": complete,
        "unknown_cost_n": len(items) - len(known),
        "deflection_rate": (
            sum(i["route"] in auto_routes and i.get("error") is None for i in items) / len(items)
            if auto_routes and items
            else None
        ),
        "auto_routes": list(auto_routes),
    }


def routing(items: list[dict], escalation_routes: Sequence[str] = ()) -> dict | None:
    """T2. Exact policy agreement on labelled cases; labels are not optimality proof.

    correct_answer_wrong_route_rate is mismatch & correct / labelled attempted.
    Escalation precision/recall use declared route groups; zero observed
    escalations gives recall zero whenever escalation was required.
    """
    labelled = [i for i in items if i.get("expected_route") is not None]
    if not labelled:
        return None
    grid = {
        "route_right_verdict_right": 0,
        "route_right_verdict_wrong": 0,
        "route_wrong_verdict_right": 0,
        "route_wrong_verdict_wrong": 0,
    }
    for item in labelled:
        key = (
            f"route_{'right' if item['route'] == item['expected_route'] else 'wrong'}"
            f"_verdict_{'right' if item['correct'] else 'wrong'}"
        )
        grid[key] += 1
    rate = grid["route_wrong_verdict_right"] / len(labelled)
    result = {
        "n_labelled": len(labelled),
        "label_coverage": len(labelled) / len(items),
        "routing_accuracy": (grid["route_right_verdict_right"] + grid["route_right_verdict_wrong"])
        / len(labelled),
        "grid": grid,
        "correct_answer_wrong_route_rate": rate,
        "lucky_hit_rate": rate,  # deprecated alias: no claim that the answer was accidental
        "escalation_routes": list(escalation_routes),
        "escalation_precision": None,
        "escalation_recall": None,
        "n_required_escalations": 0,
        "n_observed_escalations": 0,
    }
    if escalation_routes:
        sent = [i for i in labelled if i["route"] in escalation_routes]
        should = [i for i in labelled if i["expected_route"] in escalation_routes]
        hits = sum(i["expected_route"] in escalation_routes for i in sent)
        result.update(
            n_required_escalations=len(should),
            n_observed_escalations=len(sent),
            escalation_precision=hits / len(sent) if sent else None,
            escalation_recall=hits / len(should) if should else None,
        )
    return result


def stage_accuracy(items: list[dict]) -> dict[str, dict] | None:
    """T1 optional. Only stages with an explicit user-supplied boolean are scored."""
    tallies: dict[str, list[bool]] = defaultdict(list)
    for item in items:
        for name, stage in (item.get("stages") or {}).items():
            if isinstance(stage, dict) and type(stage.get("correct")) is bool:
                tallies[name].append(stage["correct"])
    return {
        name: {"n": len(values), "accuracy": sum(values) / len(values)}
        for name, values in sorted(tallies.items())
    } or None


def aggregate(items: list[dict], route_policy: dict) -> dict:
    """The one aggregation path used by the harness and artifact validation."""
    result = {
        "attempted": len(items),
        "succeeded": sum(i["error"] is None for i in items),
        "errors": sum(i["error"] is not None for i in items),
        "measurement_errors": sum(i.get("error_stage") in ("scorer", "validation") for i in items),
        "accuracy_attempted": accuracy_attempted(items),
        "per_route": per_route(items),
        "economics": economics(items, route_policy["auto_routes"]),
    }
    route_metrics = routing(items, route_policy["escalation_routes"])
    if route_metrics is not None:
        result["routing"] = route_metrics
    stages = stage_accuracy(items)
    if stages is not None:
        result["stages"] = stages
    return result


def _p95(values: list[float]) -> float:
    """Nearest-rank p95; latency measures pipeline execution, excluding scoring."""
    if not values:
        return 0.0
    rank = max(0, -(-95 * len(values) // 100) - 1)
    return sorted(values)[rank]
