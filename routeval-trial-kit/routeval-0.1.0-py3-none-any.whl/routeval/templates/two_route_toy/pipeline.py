"""Toy support-bot with two routes — the zero-API-key hello world.

Route "cheap": a keyword lookup (deterministic, effectively free).
Route "escalate": a stubbed "big model" (canned answers, priced like an API).

Deliberately imperfect, so the routeval report has something to say:
the cheap route has two stale answers, one hard question gets LUCKY on the
cheap route (right answer, wrong path), one escalation is wrong, and one
input crashes the pipeline to demonstrate dead-letter accounting.
"""

from __future__ import annotations

from routeval import Decision

KB = {
    "2+2": "4",
    "17*23": "391",
    "refund": "30-day replacement",
    "shipping cutoff": "8pm",
    "ireland": "yes",
    "hours": "9am-6pm weekdays",
    "track": "link in your confirmation email",
    "gift wrap": "yes, at checkout",
    "cancel": "within 1 hour of ordering",
    "price match": "no",  # stale: policy changed
    "battery": "lithium, 2-year life",  # stale: spec changed
    "student discount": "10%",
    "warranty": "no, unless seal broken",  # coincidentally right on a hard case
}

ESCALATION = {
    "My order arrived damaged AND late, and I paid with a gift card — what are my options?": "replacement plus shipping credit; gift card refund to balance",
    "Can I return a personalised item that has a manufacturing defect?": "yes, defects override personalisation exclusion",
    "Do your protein bars risk cross-contamination with peanuts?": "shared facility; not certified allergen-free",
    "My bank started a chargeback; can I still resolve this with you directly?": "yes, if the chargeback is withdrawn first",
    "Can I combine two promo codes with my loyalty points on one order?": "one code per order; loyalty points stack",
    # deliberately wrong answer:
    "Are there export restrictions if I bulk-order microcontrollers to Serbia?": "no restrictions apply",
}


def pipeline(user_input: str) -> Decision:
    if "SYSTEM OVERLOAD" in user_input:
        return Decision(None, route=None, cost_usd=0, error="backend 500: stub outage")

    lowered = user_input.lower()
    for keyword, answer in KB.items():
        if keyword in lowered:
            return Decision(answer=answer, route="cheap", cost_usd=0.0001)

    answer = ESCALATION.get(user_input, "let me connect you to a specialist")
    return Decision(answer=answer, route="escalate", model="stub-large", cost_usd=0.01)
