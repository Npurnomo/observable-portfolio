"""Replay a user's sync/async callable and persist a complete schema-1 artifact."""

from __future__ import annotations

import hashlib
import inspect
import subprocess
import time
from collections.abc import Callable, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from routeval import __version__, metrics
from routeval.artifact import SCHEMA_VERSION, digest, load_run, read_json, write_run
from routeval.baseline import compare, compatibility_issues, validate_run, validate_tolerances
from routeval.decision import Decision, route_names, validate_decision, validate_golden_row
from routeval.economics import load_pricing, resolve_cost
from routeval.scorers import Scorer, contains, exact, normalized


def is_async(function: Callable) -> bool:
    return inspect.iscoroutinefunction(function) or inspect.iscoroutinefunction(
        getattr(function, "__call__", None)  # noqa: B004 — inspect async callable objects
    )


class Harness:
    def __init__(
        self,
        pipeline: Callable[[Any], Any],
        *,
        scorer: Scorer = normalized,
        scorer_id: str | None = None,
        scorer_version: str | None = None,
        auto_routes: Sequence[str] = (),
        escalation_routes: Sequence[str] = (),
        cost_basis: str = "deployment",
        echo_inputs: bool = False,
        pricing_path: str | None = None,
        runs_dir: str | Path | None = "runs",
    ) -> None:
        if not callable(pipeline) or not callable(scorer):
            raise TypeError("pipeline and scorer must be callable")
        self.pipeline, self.scorer = pipeline, scorer
        self.route_policy = {
            "auto_routes": list(route_names(auto_routes, "auto_routes")),
            "escalation_routes": list(route_names(escalation_routes, "escalation_routes")),
        }
        if set(self.route_policy["auto_routes"]) & set(self.route_policy["escalation_routes"]):
            raise ValueError("automatic and escalation routes must be disjoint")
        if not isinstance(cost_basis, str) or not cost_basis.strip():
            raise ValueError("cost_basis must be a nonempty string")
        self.cost_basis = cost_basis
        self.scorer_meta = {
            "id": scorer_id
            or (
                f"{getattr(scorer, '__module__', type(scorer).__module__)}."
                f"{getattr(scorer, '__qualname__', type(scorer).__qualname__)}"
            ),
            "version": scorer_version
            or (
                __version__
                if any(scorer is builtin for builtin in (exact, normalized, contains))
                else None
            ),
        }
        for key, value in self.scorer_meta.items():
            if value is not None and (not isinstance(value, str) or not value.strip()):
                raise ValueError(f"scorer {key} must be a nonempty string")
        self.echo_inputs = echo_inputs
        self.pricing = load_pricing(pricing_path)
        self.pricing_meta = {
            "source": "user" if pricing_path else "bundled",
            "sha256": digest(self.pricing),
        }
        self.runs_dir = Path(runs_dir) if runs_dir is not None else None

    def run(
        self,
        golden: str | Path | list[dict],
        note: str = "",
        *,
        baseline: str | Path | dict | None = None,
        tolerances: dict | None = None,
    ) -> dict:
        if is_async(self.pipeline) or is_async(self.scorer):
            raise ValueError("async pipeline/scorer requires await harness.arun(...)")
        rows, run, previous = self._prepare(golden, note, baseline, tolerances)
        for row in rows:
            record = self._record(row)
            t0 = time.perf_counter()
            try:
                decision = self.pipeline(row["input"])
                if inspect.isawaitable(decision):
                    _close_coroutine(decision)
                    raise ValueError("awaitable pipeline result requires harness.arun(...)")
            except Exception as exc:  # noqa: BLE001 — retain every attempted failure
                self._fail(record, "pipeline", exc)
            else:
                self._accept(record, decision)
            record["latency_ms"] = (time.perf_counter() - t0) * 1000
            if record["error"] is None:
                try:
                    result = self.scorer(row["expected"], record["answer"])
                    self._score(record, result)
                except Exception as exc:  # noqa: BLE001 — retain every attempted failure
                    self._fail(record, "scorer", exc)
            run["items"].append(record)
        return self._finish(run, previous, tolerances)

    async def arun(
        self,
        golden: str | Path | list[dict],
        note: str = "",
        *,
        baseline: str | Path | dict | None = None,
        tolerances: dict | None = None,
    ) -> dict:
        """Sequential async replay; no implicit concurrency or provider retries."""
        rows, run, previous = self._prepare(golden, note, baseline, tolerances)
        for row in rows:
            record = self._record(row)
            t0 = time.perf_counter()
            try:
                decision = self.pipeline(row["input"])
                if inspect.isawaitable(decision):
                    decision = await decision
            except Exception as exc:  # noqa: BLE001 — retain every attempted failure
                self._fail(record, "pipeline", exc)
            else:
                self._accept(record, decision)
            record["latency_ms"] = (time.perf_counter() - t0) * 1000
            if record["error"] is None:
                try:
                    result = self.scorer(row["expected"], record["answer"])
                    if inspect.isawaitable(result):
                        result = await result
                    self._score(record, result)
                except Exception as exc:  # noqa: BLE001 — retain every attempted failure
                    self._fail(record, "scorer", exc)
            run["items"].append(record)
        return self._finish(run, previous, tolerances)

    def _prepare(
        self,
        golden: str | Path | list[dict],
        note: str,
        baseline: str | Path | dict | None,
        tolerances: dict | None,
    ) -> tuple[list[dict], dict, dict | None]:
        validate_tolerances(tolerances)
        rows, golden_meta = _load_golden(golden)
        policy = {
            "scorer": self.scorer_meta,
            "route_policy": self.route_policy,
            "pricing_sha256": self.pricing_meta["sha256"],
            "cost_basis": self.cost_basis,
            "echo_inputs": self.echo_inputs,
            "schema_version": SCHEMA_VERSION,
        }
        run = {
            "schema_version": SCHEMA_VERSION,
            "manifest": {
                "run_id": uuid4().hex,
                "harness_version": __version__,
                "started_at": _now(),
                "finished_at": None,
                "status": "running",
                "git_sha": _git_sha(),
                "config_hash": digest(policy),
                "golden_set": golden_meta,
                "pricing_file": dict(self.pricing_meta),
                "scorer": dict(self.scorer_meta),
                "route_policy": dict(self.route_policy),
                "cost_basis": self.cost_basis,
                "note": note,
            },
            "items": [],
        }
        previous = load_run(baseline) if isinstance(baseline, (str, Path)) else baseline
        if previous is not None:
            issues = compatibility_issues(run, previous) + validate_run(previous)
            if not issues and not previous["aggregates"]["economics"]["cost_complete"]:
                issues.append("baseline has incomplete cost")
            if issues:
                raise ValueError("baseline is incompatible: " + "; ".join(dict.fromkeys(issues)))
        return rows, run, previous

    def _record(self, row: dict) -> dict:
        record = {
            "id": row["id"],
            "input_hash": digest(row["input"]),
            "expected": row["expected"],
            "expected_route": row.get("expected_route"),
            "tier": row.get("tier"),
            "answer": None,
            "correct": False,
            "route": None,
            "cost_usd": None,
            "cost_source": "unknown",
            "model": None,
            "tokens": None,
            "latency_ms": 0.0,
            "stages": None,
            "error": None,
            "error_stage": None,
        }
        if self.echo_inputs:
            record["input_echo"] = row["input"]
        return record

    def _accept(self, record: dict, decision: Any) -> None:
        try:
            if not isinstance(decision, Decision):
                raise TypeError(f"pipeline returned {type(decision).__name__}, expected Decision")
            # Retain independently valid booked cost even if another field is malformed.
            if decision.cost_usd is not None:
                record["cost_usd"] = resolve_cost(decision, self.pricing)
                record["cost_source"] = "reported"
            validate_decision(decision)
            record.update(
                answer=decision.answer,
                route=decision.route,
                cost_usd=resolve_cost(decision, self.pricing),
                model=decision.model,
                tokens={"in": decision.tokens_in, "out": decision.tokens_out},
                stages=decision.stages or None,
            )
            if decision.cost_usd is None and record["cost_usd"] is not None:
                record["cost_source"] = "estimated"
            if decision.error is not None:
                self._fail(record, "pipeline", decision.error)
        except Exception as exc:  # noqa: BLE001 — retain every attempted failure
            self._fail(record, "validation", exc)

    @staticmethod
    def _score(record: dict, result: Any) -> None:
        if inspect.isawaitable(result):
            _close_coroutine(result)
            raise ValueError("awaitable scorer result requires harness.arun(...)")
        if type(result) is not bool:
            raise ValueError(
                "scorer must return bool; apply an explicit threshold to numeric scores"
            )
        record["correct"] = result

    @staticmethod
    def _fail(record: dict, stage: str, error: Exception | str) -> None:
        record["correct"] = False
        record["error_stage"] = stage
        record["error"] = error if isinstance(error, str) else f"{type(error).__name__}: {error}"

    def _finish(self, run: dict, previous: dict | None, tolerances: dict | None) -> dict:
        run["aggregates"] = metrics.aggregate(run["items"], self.route_policy)
        run["manifest"].update(
            finished_at=_now(),
            status="measurement_failed" if run["aggregates"]["measurement_errors"] else "complete",
        )
        path = None
        if self.runs_dir is not None:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
            path = self.runs_dir / f"run-{stamp}-{run['manifest']['run_id']}.json"
            run["manifest"]["artifact_path"] = str(path)
        if previous is not None:
            run["baseline"] = compare(run, previous, tolerances)
        if path is not None:
            write_run(run, path)
        return run


def _load_golden(golden: str | Path | list[dict]) -> tuple[list[dict], dict]:
    if isinstance(golden, (str, Path)):
        path = Path(golden)
        raw = path.read_bytes()
        rows = []
        for line_number, line in enumerate(raw.decode("utf-8").splitlines(), 1):
            if line.strip():
                try:
                    rows.append(read_json(line))
                except ValueError as exc:
                    raise ValueError(f"{path}:{line_number}: {exc}") from exc
        meta = {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "n": len(rows)}
    else:
        rows = list(golden)
        meta = {"path": None, "sha256": digest(rows), "n": len(rows)}
    if not rows:
        raise ValueError("golden set must contain at least one item")
    rows = [validate_golden_row(row, index) for index, row in enumerate(rows)]
    if len({row["id"] for row in rows}) != len(rows):
        raise ValueError("golden set contains duplicate IDs")
    return rows, meta


def _close_coroutine(value: Any) -> None:
    if inspect.iscoroutine(value):
        value.close()


def _git_sha() -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")
